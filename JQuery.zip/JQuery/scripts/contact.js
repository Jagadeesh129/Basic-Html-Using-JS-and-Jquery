$(document).ready(function () {

    var exp= /^([a-zA-Z0-9\.\ -_$#!^&*]+)@([a-zA-Z0-9]+)\.([a-z]+)(.[a-z]+)?$/ ;

    $("#name").blur(function () {
        validateName();
    });

    $("#name").on('input',function () {
        validateName();
    });

    $("#email").blur(function () {
        validateEmail();
    });

    $("#email").on('input',function () {
        validateEmail();
    });

    $("#organization").blur(function () {
        validateOrganization();
    });

    $("#organization").on('input',function () {
        validateOrganization();
    });

    var errorMessages = {
        name: {
            required:"Name is Required"
        },
        email : {
            required : "Email is Required",
            validEmail : 'Invalid'
        },
        organization : {
            required : "Organization is Required"
        },
        default : '*',
        fillAllFields : "Please Fill all Required Fields",
    };


    function validateName() {
        let name = $("#name").val().trim();
        if(name == "") {
            $("#name-required").text(errorMessages.name.required);
            $("#alert-fill-required").show();
            return false;
        }
        else {
            $("#name-required").text(errorMessages.default);
            checkAllFields();
            return true;
        }
    }

    $('input[name = "gender"]').click(function() {
        const genders = $('input[name = "gender"]');
        setTimeout(() =>{
            if(genders[0].checked) {
                alert("Hello Sir");
            }
            else{
                alert("Hello Lady");
            }
        },10);
    });

    function validateEmail() {
        let email = $("#email").val().trim();
        if(email == "") {
            $("#email-required").text(errorMessages.email.required);
            $("#alert-fill-required").show();
            return false;
        }
        else {
            checkAllFields();
            isValidEmail();
        }
    }

    function isValidEmail() {
        let email = $("#email").val().trim();
        if(email.match(exp)){
            $("#email-required").text(errorMessages.default);
            return true;
        }
        else{
            $("#email-required").text(errorMessages.email.validEmail);
            return false;
        }
    }

    function validateOrganization() {
        let org = $("#organization").val().trim();
        if(org == "") {
            $("#organization-required").text(errorMessages.organization.required);
            $("#alert-fill-required").show();
            return false;
        }
        else {
            $("#organization-required").text(errorMessages.default);
            checkAllFields();
            return true;
        }
    }

    
    $("#state").change(function() {
        const promoCode=$("#promo-code");
        promoCode.val($("#state").val()+"-PROMO");
    });

    $("#clear").click(
        function reset() {
            $("#name-required").text('errorMessages.default');
            $("#email-required").text('errorMessages.default');
            $("#ordanization-required").text('errorMessages.default');
            $("#alert-fill-required").hide();
            const form = $("#myform");
            form.trigger('reset');
        }
    );

    function checkAllFields() {
        const name = $("#name").val().trim();
        const org = $("#organization").val().trim();
        const email = $("#email").val().trim();
        if(name.length>0 && org.length>0 &&email.length>0 && isValidEmail()){
            $("#alert-fill-required").hide();
            return true;
        }    
        return false;
    }

    $("#submit").click(function() {
        const isvalidName = validateName();
        const isValidEmail = validateEmail();
        const isValidOrganization = validateOrganization();
        if(isvalidName && isValidEmail && isValidOrganization){
            alert("Successfully sent");
            reset();
        }
    });

});