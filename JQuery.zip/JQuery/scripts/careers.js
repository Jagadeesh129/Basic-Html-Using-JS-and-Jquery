$(document).ready(function (){

    $("#name").blur(validateName);
    
    $("#name").on('input',validateName);

    $("#email").blur(function (){
        validateEmail();
    });

    $("#email").on('input',function (){
        validateEmail();
    });

    $("#dummybrowse").click(function(){
        $("#browse").click();

    });

    function validateName(){
        let name = $("#name").val().trim();
        if(name == "") {
            $("#name-required").show();
            $(".required-name").hide();
            return false;
        }
        else {
            $("#name-required").hide();
            $(".required-name").show();
            return true;
        }
    }

    function validateEmail() {
        let email = $("#email").val().trim();
        if(email == "") {
            $("#email-invalid").hide();
            $(".required-email").hide();
            $("#email-required").show();
            return false;
        }
        else {
            $("#email-required").hide();
            var exp = /^([a-zA-Z0-9\.\ -_$#!^&*]+)@([a-zA-Z0-9]+)\.([a-z]+)(.[a-z]+)?$/
            if(email.match(exp)){
                $("#email-invalid").hide();
                $(".required-email").show();
                return true;
            }
            else{
                $("#email-invalid").show();
                $(".required-email").hide();
                return false;
            }
        }
    }
    
    $("#browse").change(function() {
        const fileName = $("#browse").val();
        console.log(fileName);
        if(fileName != ""){
            const index = fileName.lastIndexOf("\\");
            $("#resumename").val(fileName.slice(index+1));
            validateResume();
        }
    });

    function validateResume() {
        let resume = $("#resumename").val();
        if(resume == ""){
            $(".required-resume").hide();
            $("#resume-required").show();
            return false;
        }
        else {
            $("#resume-required").hide();
            $(".required-resume").show();
            return true;
        }
    }

    $("#submit").click(function() {
        const nameIsThere = validateName();
        const emailIsThere = validateEmail();
        const resumeIsThere = validateResume();
        if(nameIsThere&&emailIsThere&&resumeIsThere){
            alert("Successfully sent");
            const form = $("#myform");
            form.trigger('reset');
        }
    })
});