function validateName() {
    var name=document.getElementById('name').value.trim();
    if(name==""){
        document.getElementById("name-required").textContent="Name is required";
        return false;
    }
    else{
        document.getElementById("name-required").textContent="*";
        return true;
    }
}

var exp= /^([a-zA-Z0-9\.\ -_$#!^&*]+)@([a-zA-Z0-9]+)\.([a-z]+)(.[a-z]+)?$/

function validateEmail() {
    var email=document.getElementById("email").value.trim();
    if(email==""){
        document.getElementById("email-required").textContent="Email is required";
        return false;
    }
    else {
        if(email.match(exp)){
            document.getElementById("email-required").textContent="*";
            return true;
        }
        else{
            document.getElementById("email-required").textContent="Invalid Email";
            return false;
        }
    }
}


function selectFiles() {
    var fileinput = document.getElementById("browse");
    fileinput.click();
}

function fileValue() {
    var fileinput = document.getElementById("browse");
    if(fileinput.value!=""){
        var textinput = document.getElementById("resumename");
        const index=fileinput.value.lastIndexOf("\\");
        textinput.value = fileinput.value.slice(index+1);
        validateResume();
    }
}

function validateResume() {
    var resume=document.getElementById("resumename").value;
    if(resume==""){
        document.getElementById("resume-required").textContent="Upload resume";
        return false;
    }
    else{
        document.getElementById("resume-required").textContent="*";
        return true;
    }
}

function validateForm() {
    let isValidName = validateName();
    let isValidEmail = validateEmail();
    let isValidResume = validateResume();
    if(isValidEmail && isValidName && isValidResume){
        alert("Successfully sent");
        location.reload();
    }
}