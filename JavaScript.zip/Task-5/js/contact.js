var regexp= /^([a-zA-Z0-9\.\ -_$#!^&*]+)@([a-zA-Z0-9]+)\.([a-z]+)(.[a-z]+)?$/;

var errorMessages = {
    name : {
        required : "Name is Required"
    },

    email : {
        required : "Email is Required",
        invalid : "Invalid Email"
    },

    organization : {
        required: "Organization name is required",
    },

    fillAllFields : {
        default : "",
        message : "Please fill all the required fields below",
    },

    default : '*',

}

function validateName() {
    let name=document.getElementById('name').value.trim();
    if(name==""){
        document.getElementById("name-required").textContent=errorMessages.name.required;
        setPleaseFillAllFields();
        return false;
    }
    else{
        document.getElementById("name-required").textContent=errorMessages.default;
        removePleaseFillAllFields();
        return true;
    }
}

function sayHello() {
    setTimeout(() =>{
        let genders=document.getElementsByName("gender");
        if(genders[0].checked){
            alert("Hello Sir");
        }
        else{
            alert("Hello Lady");
        }
    },1);
}

function validateEmail() {
    let email=document.getElementById("email").value.trim();
    if(email==""){
        document.getElementById("email-required").textContent=errorMessages.email.required;
        setPleaseFillAllFields();
        return false;
    }
    else {
        removePleaseFillAllFields();
        if(email.match(regexp)){
            document.getElementById("email-required").textContent=errorMessages.default;
            return true;
        }
        else{
            document.getElementById("email-required").textContent=errorMessages.email.invalid;
            return false;
        }
    }
}



function checkAllFieldsAreValid() {
    let isValidName = validateName();
    let isValidEmail =validateEmail();
    let isValidOrganization =validateOrganization();
    if(isValidName && isValidEmail && isValidOrganization){
        document.getElementById("alert-fill-required").textContent=errorMessages.fillAllFields.default;
        return true;
    }
}

function validateOrganization() {
    let org=document.getElementById("organization").value.trim();
    if(org==""){
        document.getElementById("organization-required").textContent=errorMessages.organization.required;;
        setPleaseFillAllFields();
        return false;
    }
    else{
        document.getElementById("organization-required").textContent=errorMessages.default;
        removePleaseFillAllFields();
        return true;
    }
}

function promoCode() {
    let state=document.getElementById("state");
    let promo = document.getElementById("promo-code");
    promo.value=state.value + "-PROMO";
}

function submitForm() {
    if(checkAllFieldsAreValid()){
        alert("Successfully sent");
        resetForm();
    }
}

function resetForm() {
    let form=document.getElementById("myform");
    form.reset();
    resetValidation();
}

function resetValidation() {
    document.getElementById("alert-fill-required").textContent=errorMessages.fillAllFields.default;
    document.getElementById("organization-required").textContent=errorMessages.default;
    document.getElementById("email-required").textContent=errorMessages.default;
    document.getElementById("name-required").textContent=errorMessages.default;
}

function setPleaseFillAllFields() {
    document.getElementById("alert-fill-required").textContent=errorMessages.fillAllFields.message;
}

function removePleaseFillAllFields() {
    let email = document.getElementById("email").value.trim();
    let name = document.getElementById("name").value.trim();
    let org = document.getElementById("organization").value.trim();
    if(email.length>0 && name.length>0 && org.length>0 && email.match(regexp)){
        document.getElementById("alert-fill-required").textContent=errorMessages.fillAllFields.default;
        return true;
    }
}